PIXEL INVADERS

Gameboy-Presets Game for PixelVision 8 by Traslogan

CONTROLS:

Start = S (Default)
Select = A (Default) For choosing difficulty
Fire (A) = X (Default)
CTRL+4 = Reset Game (Default)